public class Localidad {
    private String nombre;
    private double precio;
    private int capacidadMaxima;
    private int vendidos;

    public Localidad(String nombre, double precio, int capacidadMaxima) {
        this.nombre = nombre;
        this.precio = precio;
        this.capacidadMaxima = capacidadMaxima;
        this.vendidos = 0;
    }

    public boolean tieneEspacio(int cantidad) {
        return (vendidos + cantidad <= capacidadMaxima);
    }

    public int venderBoletos(int cantidad) {
        int disponibles = capacidadMaxima - vendidos;
        int aVender = Math.min(disponibles, cantidad);
        vendidos += aVender;
        return aVender;
    }

    public String getNombre() { return nombre; }
    public double getPrecio() { return precio; }
    public int getVendidos() { return vendidos; }
    public int getDisponibles() { return capacidadMaxima - vendidos; }
}
