import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Sistema sistema = new Sistema();
        Scanner sc = new Scanner(System.in);
        boolean salir = false;

        while (!salir) {
            System.out.println("\n1. Nuevo comprador\n2. Nueva solicitud de boletos\n3. Consultar disponibilidad total");
            System.out.println("4. Consultar disponibilidad individual\n5. Reporte de caja\n6. Salir");
            System.out.print("Seleccione opción: ");
            int opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("Nombre: ");
                    String nombre = sc.nextLine();
                    System.out.print("Email: ");
                    String email = sc.nextLine();
                    System.out.print("Cantidad boletos: ");
                    int cantidad = sc.nextInt();
                    System.out.print("Presupuesto: ");
                    double presupuesto = sc.nextDouble();
                    sistema.setComprador(new Comprador(nombre, email, cantidad, presupuesto));
                    break;
                case 2:
                    sistema.procesarCompra();
                    break;
                case 3:
                    sistema.consultarDisponibilidadTotal();
                    break;
                case 4:
                    System.out.print("Nombre de la localidad: ");
                    String loc = sc.nextLine();
                    sistema.consultarDisponibilidadLocalidad(loc);
                    break;
                case 5:
                    sistema.reporteCaja();
                    break;
                case 6:
                    salir = true;
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        }
    }
}
