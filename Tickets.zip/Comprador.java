public class Comprador {
    private String nombre;
    private String email;
    private int cantidadBoletosDeseada;
    private double presupuesto;

    public Comprador(String nombre, String email, int cantidadBoletosDeseada, double presupuesto) {
        this.nombre = nombre;
        this.email = email;
        this.cantidadBoletosDeseada = cantidadBoletosDeseada;
        this.presupuesto = presupuesto;
    }

    public String getNombre() { return nombre; }
    public String getEmail() { return email; }
    public int getCantidadBoletosDeseada() { return cantidadBoletosDeseada; }
    public double getPresupuesto() { return presupuesto; }
}
