import java.util.Random;

public class Ticket {
    private int numero;
    private boolean valido;

    public void generarNumero() {
        Random rand = new Random();
        numero = rand.nextInt(15000) + 1;
    }

    public boolean validar() {
        Random rand = new Random();
        int a = rand.nextInt(15000) + 1;
        int b = rand.nextInt(15000) + 1;
        int min = Math.min(a, b);
        int max = Math.max(a, b);
        valido = (numero >= min && numero <= max);
        return valido;
    }

    public int getNumero() { return numero; }
    public boolean esValido() { return valido; }
}