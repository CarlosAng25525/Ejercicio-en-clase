import java.util.*;

public class Sistema {
    private List<Localidad> localidades;
    private Comprador comprador;

    public Sistema() {
        localidades = new ArrayList<>();
        localidades.add(new Localidad("Localidad 1", 100, 20));
        localidades.add(new Localidad("Localidad 5", 500, 20));
        localidades.add(new Localidad("Localidad 10", 1000, 20));
    }

    public void setComprador(Comprador c) {
        comprador = c;
    }

    public void procesarCompra() {
        Ticket ticket = new Ticket();
        ticket.generarNumero();

        if (!ticket.validar()) {
            System.out.println("Ticket no válido. No puede comprar boletos.");
            return;
        }

        Random rand = new Random();
        Localidad loc = localidades.get(rand.nextInt(localidades.size()));

        System.out.println("Localidad asignada: " + loc.getNombre());

        if (!loc.tieneEspacio(1)) {
            System.out.println("Localidad sin espacio.");
            return;
        }

        int maxComprables = comprador.getCantidadBoletosDeseada();
        int disponibles = loc.getDisponibles();
        int aComprar = Math.min(maxComprables, disponibles);

        if (loc.getPrecio() * aComprar > comprador.getPresupuesto()) {
            System.out.println("Presupuesto insuficiente para esta localidad.");
            return;
        }

        int vendidos = loc.venderBoletos(aComprar);
        System.out.println("Boletos vendidos: " + vendidos + " en " + loc.getNombre());
    }

    public void consultarDisponibilidadTotal() {
        for (Localidad l : localidades) {
            System.out.println(l.getNombre() + ": Disponibles = " + l.getDisponibles() + ", Vendidos = " + l.getVendidos());
        }
    }

    public void consultarDisponibilidadLocalidad(String nombre) {
        for (Localidad l : localidades) {
            if (l.getNombre().equalsIgnoreCase(nombre)) {
                System.out.println("Disponibles en " + nombre + ": " + l.getDisponibles());
                return;
            }
        }
        System.out.println("Localidad no encontrada.");
    }

    public void reporteCaja() {
        double total = 0;
        for (Localidad l : localidades) {
            total += l.getVendidos() * l.getPrecio();
        }
        System.out.println("Total recaudado: $" + total);
    }
}
